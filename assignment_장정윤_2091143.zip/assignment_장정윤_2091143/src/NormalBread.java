public class NormalBread extends Toast{
    public NormalBread() {
        addName(" 식빵 토스트");
        addKcal(300);
    }
}
