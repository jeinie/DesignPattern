public abstract class ToppingDecorator extends Toast{
    Toast toast;
    public ToppingDecorator() {

    }
    public abstract String Name();

    public abstract int Kcal();
}
