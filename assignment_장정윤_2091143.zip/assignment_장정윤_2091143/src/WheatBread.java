public class WheatBread extends Toast{
    public WheatBread() {
        addName(" 호밀식빵 토스트");
        addKcal(250);
    }
}
