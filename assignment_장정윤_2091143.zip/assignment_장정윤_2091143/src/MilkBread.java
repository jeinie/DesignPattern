public class MilkBread extends Toast{
    public MilkBread() {
        addName(" 우유식빵 토스트");
        addKcal(350);
    }
}
