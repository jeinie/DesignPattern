public class ButterBread extends Toast{
    public ButterBread() {
        addName(" 버터식빵 토스트");
        addKcal(400);
    }
}
